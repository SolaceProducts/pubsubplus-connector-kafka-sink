# Solace PubSub+ Connector Kafka Sink

The Solace Sink Connector allows for each record in Kafka to generate an event in the Solace Event Mesh

For detailed description refer to the project GitHub page at [https://github.com/SolaceProducts/pubsubplus-connector-kafka-Sink](https://github.com/SolaceProducts/pubsubplus-connector-kafka-Sink)